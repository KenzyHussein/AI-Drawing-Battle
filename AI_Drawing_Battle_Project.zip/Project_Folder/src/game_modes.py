import random
import time


class BeatTheTimerMode:
    """
    Phase 2 – Mode 2: Beat the Timer
    - Picks a secret word
    - 10-second countdown
    - Checks Top-3 AI predictions continuously
    - Calculates score based on remaining time
    """

    def __init__(self, classes, duration=10.0):
        self.classes = classes
        self.duration = duration
        self.score = 0
        self.rounds_played = 0

        self.secret_word = None
        self.start_time = None
        self.state = "IDLE"  # IDLE, PLAYING, WON, LOST
        self.last_round_points = 0

    def start_round(self):
        self.secret_word = random.choice(self.classes)
        self.start_time = time.time()
        self.state = "PLAYING"
        self.last_round_points = 0
        self.rounds_played += 1

    def get_remaining_time(self):
        if self.state != "PLAYING" or self.start_time is None:
            return 0.0
        elapsed = time.time() - self.start_time
        return max(0.0, self.duration - elapsed)

    def update(self, top3_predictions):
        if self.state != "PLAYING":
            return self.state

        remaining = self.get_remaining_time()
        predicted_labels = [label.lower() for label, _ in top3_predictions]

        # Check if AI guessed the secret word in Top-3
        if self.secret_word.lower() in predicted_labels:
            self.state = "WON"
            # Base 100 pts + speed bonus (up to 100 pts)
            self.last_round_points = int(100 + (remaining / self.duration) * 100)
            self.score += self.last_round_points
            return self.state

        # Check timeout
        if remaining <= 0.0:
            self.state = "LOST"
            self.last_round_points = 0

        return self.state


class DrawAndGuessMode:
    """
    Phase 3 – Mode 3: Draw and Guess (2 Players)
    - Step 1 (REVEAL): Show secret word to Player 1 only
    - Step 2 (DRAWING): Player 1 draws via camera (AI predictions strictly hidden!)
    - Step 3 (GUESSING): Player 2 views the reconstructed drawing and types their guess
    - Step 4 (RESULT): Compare guess with secret word & award points
    """

    def __init__(self, classes, draw_duration=15.0):
        self.classes = classes
        self.draw_duration = draw_duration

        self.p1_score = 0
        self.p2_score = 0

        self.secret_word = None
        self.state = "REVEAL"  # REVEAL, DRAWING, GUESSING, RESULT
        self.draw_start_time = None
        self.player2_guess = ""
        self.is_correct = False

    def start_round(self):
        self.secret_word = random.choice(self.classes)
        self.state = "REVEAL"
        self.draw_start_time = None
        self.player2_guess = ""
        self.is_correct = False

    def begin_drawing(self):
        if self.state == "REVEAL":
            self.state = "DRAWING"
            self.draw_start_time = time.time()

    def finish_drawing(self):
        if self.state == "DRAWING":
            self.state = "GUESSING"

    def get_draw_remaining_time(self):
        if self.state != "DRAWING" or self.draw_start_time is None:
            return 0.0
        elapsed = time.time() - self.draw_start_time
        return max(0.0, self.draw_duration - elapsed)

    def update_timer(self):
        if self.state == "DRAWING" and self.get_draw_remaining_time() <= 0.0:
            self.finish_drawing()

    def handle_typing(self, key_code):
        """Captures Player 2's keyboard guess during GUESSING phase."""
        if self.state != "GUESSING":
            return

        if key_code in (13, 10):  # Enter key
            self.submit_guess()
        elif key_code in (8, 127):  # Backspace
            self.player2_guess = self.player2_guess[:-1]
        elif 32 <= key_code <= 126:  # Printable ASCII
            char = chr(key_code)
            if char.isalpha() or char == " ":
                self.player2_guess += char

    def submit_guess(self):
        guess_clean = self.player2_guess.strip().lower()
        target_clean = self.secret_word.strip().lower()

        self.is_correct = (guess_clean == target_clean)
        if self.is_correct:
            # Both drawer and guesser get points for successful communication
            self.p1_score += 100
            self.p2_score += 100

        self.state = "RESULT"
