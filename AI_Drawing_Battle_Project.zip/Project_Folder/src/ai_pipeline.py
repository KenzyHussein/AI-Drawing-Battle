import time
import cv2
import numpy as np


class AIPipeline:
    """
    Phase 1 & Phase 4:
    - Connects DrawingCapture coordinates to Image Preprocessing (Member 2)
    - Runs CNN Inference periodically (Member 3)
    - Tracks latency and logs errors for model improvement
    """

    def __init__(self, classes, model_path=None, inference_interval=0.4):
        self.classes = classes
        self.inference_interval = inference_interval
        self.last_inference_time = 0.0
        self.last_point_count = 0

        self.latest_predictions = []  # List of tuples: [(label, confidence), ...]
        self.inference_times_ms = []
        self.error_logs = []

        # Load Member 3's model if provided
        self.model = self._load_model(model_path)

    def _load_model(self, model_path):
        if model_path is None:
            print("[AIPipeline] No model path provided. Running in Simulation/Fallback mode.")
            return None
        try:
            import tensorflow as tf
            model = tf.keras.models.load_model(model_path)
            print(f"[AIPipeline] Loaded Keras model from {model_path}")
            return model
        except Exception as e:
            print(f"[AIPipeline] Could not load model ({e}). Running in Fallback mode.")
            return None

    def strokes_to_image(self, completed_strokes, current_stroke, img_size=28):
        """
        Bridge for Member 2 (Drawing Reconstruction + Image Preprocessing):
        Converts normalized (0..1) strokes into a centered, padded 28x28 grayscale image
        matching Google Quick, Draw! format (white strokes on black background).
        Replace this body with Member 2's module call once ready.
        """
        all_strokes = completed_strokes + ([current_stroke] if current_stroke else [])
        all_pts = [pt for stroke in all_strokes for pt in stroke]

        if len(all_pts) < 2:
            return None

        # Create a high-res temporary canvas for clean anti-aliased lines
        canvas_size = 256
        canvas = np.zeros((canvas_size, canvas_size), dtype=np.uint8)

        xs = [p["x"] for p in all_pts]
        ys = [p["y"] for p in all_pts]

        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)

        span = max(max_x - min_x, max_y - min_y, 1e-5)
        margin = 0.15  # 15% padding around the drawing
        scale = (1.0 - 2 * margin) / span

        offset_x = (1.0 - (max_x - min_x) * scale) / 2.0
        offset_y = (1.0 - (max_y - min_y) * scale) / 2.0

        for stroke in all_strokes:
            for i in range(1, len(stroke)):
                x1 = int(((stroke[i - 1]["x"] - min_x) * scale + offset_x) * canvas_size)
                y1 = int(((stroke[i - 1]["y"] - min_y) * scale + offset_y) * canvas_size)
                x2 = int(((stroke[i]["x"] - min_x) * scale + offset_x) * canvas_size)
                y2 = int(((stroke[i]["y"] - min_y) * scale + offset_y) * canvas_size)
                cv2.line(canvas, (x1, y1), (x2, y2), color=255, thickness=12)

        # Resize to 28x28 and normalize to [0, 1]
        resized = cv2.resize(canvas, (img_size, img_size), interpolation=cv2.INTER_AREA)
        normalized = resized.astype(np.float32) / 255.0
        return normalized.reshape(1, img_size, img_size, 1)

    def should_run_inference(self, total_points):
        """
        Phase 1.6: Run inference at smart intervals instead of every single frame,
        and only if new points were actually drawn.
        """
        now = time.time()
        if total_points < 5 or total_points == self.last_point_count:
            return False
        if (now - self.last_inference_time) >= self.inference_interval:
            return True
        return False

    def predict_top3(self, completed_strokes, current_stroke):
        """
        Phase 1.2 - 1.5 & Phase 4:
        Generates 28x28 image, runs CNN inference, returns Top-3 predictions,
        and logs inference latency.
        """
        total_points = sum(len(s) for s in completed_strokes) + len(current_stroke)

        if not self.should_run_inference(total_points):
            return self.latest_predictions

        start_time = time.perf_counter()

        processed_img = self.strokes_to_image(completed_strokes, current_stroke)
        if processed_img is None:
            return self.latest_predictions

        if self.model is not None:
            # Real CNN Inference (Member 3)
            probs = self.model.predict(processed_img, verbose=0)[0]
            top3_idx = np.argsort(probs)[::-1][:3]
            self.latest_predictions = [
                (self.classes[i], float(probs[i])) for i in top3_idx
            ]
        else:
            # Fallback simulation so Member 4 can test gameplay immediately
            rng = np.random.default_rng(seed=total_points)
            fake_probs = rng.dirichlet(np.ones(len(self.classes)))
            top3_idx = np.argsort(fake_probs)[::-1][:3]
            self.latest_predictions = [
                (self.classes[i], float(fake_probs[i])) for i in top3_idx
            ]

        elapsed_ms = (time.perf_counter() - start_time) * 1000.0
        self.inference_times_ms.append(elapsed_ms)
        self.last_inference_time = time.time()
        self.last_point_count = total_points

        return self.latest_predictions

    def log_round_result(self, secret_word, top3_preds, success):
        """Phase 4: Log errors between model predictions and target word."""
        self.error_logs.append({
            "target": secret_word,
            "top3": [p[0] for p in top3_preds],
            "confidences": [round(p[1], 3) for p in top3_preds],
            "success": success
        })

    def get_performance_report(self):
        """Phase 4: System speed & error summary."""
        avg_ms = np.mean(self.inference_times_ms) if self.inference_times_ms else 0.0
        return {
            "total_inferences": len(self.inference_times_ms),
            "avg_inference_ms": round(float(avg_ms), 2),
            "logged_rounds": len(self.error_logs),
            "errors": [e for e in self.error_logs if not e["success"]]
        }

    def reset(self):
        self.latest_predictions = []
        self.last_point_count = 0
        self.last_inference_time = 0.0
