import cv2
import numpy as np

from hand_tracking import HandTracker
from gesture_detection import GestureDetector
from drawing_capture import DrawingCapture
from ai_pipeline import AIPipeline
from game_modes import BeatTheTimerMode, DrawAndGuessMode


# Replace with the exact class list chosen by Member 1 & Member 3
CLASSES = ["Cat", "House", "Tree", "Car", "Airplane"]

# Set path to Member 3's trained model once ready (e.g., "../models/cnn_sketch.h5")
MODEL_PATH = None


class AIDrawingBattleGame:

    def __init__(self):
        self.tracker = HandTracker()
        self.detector = GestureDetector()
        self.capture = DrawingCapture()
        self.ai = AIPipeline(classes=CLASSES, model_path=MODEL_PATH, inference_interval=0.4)

        self.mode2 = BeatTheTimerMode(classes=CLASSES, duration=10.0)
        self.mode3 = DrawAndGuessMode(classes=CLASSES, draw_duration=15.0)

        self.active_mode = "MENU"  # MENU, MODE2, MODE3
        self.camera = cv2.VideoCapture(0)

    def _reset_canvas(self):
        self.capture.clear()
        self.detector.is_drawing = False
        self.ai.reset()

    def _switch_to_mode2(self):
        self.active_mode = "MODE2"
        self._reset_canvas()
        self.mode2.start_round()

    def _switch_to_mode3(self):
        self.active_mode = "MODE3"
        self._reset_canvas()
        self.mode3.start_round()

    def _draw_strokes_on_canvas(self, canvas, width, height, color=(0, 255, 255), thickness=4):
        strokes = self.capture.completed_strokes + [self.capture.current_stroke]
        for stroke in strokes:
            for i in range(1, len(stroke)):
                p1 = (int(stroke[i - 1]["x"] * width), int(stroke[i - 1]["y"] * height))
                p2 = (int(stroke[i]["x"] * width), int(stroke[i]["y"] * height))
                cv2.line(canvas, p1, p2, color, thickness)

    def _render_menu(self, frame):
        overlay = frame.copy()
        cv2.rectangle(overlay, (40, 40), (frame.shape[1] - 40, frame.shape[0] - 40), (20, 20, 20), -1)
        frame = cv2.addWeighted(overlay, 0.8, frame, 0.2, 0)

        cv2.putText(frame, "AI DRAWING BATTLE", (70, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, (0, 255, 255), 3)
        cv2.putText(frame, "Press [2] -> Mode 2: Beat the Timer (10s vs AI)", (70, 170),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
        cv2.putText(frame, "Press [3] -> Mode 3: Draw & Guess (2 Players)", (70, 220),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
        cv2.putText(frame, "Press [Q] -> Quit & Show System Report", (70, 270),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (180, 180, 180), 2)
        return frame

    def _render_mode2(self, frame, landmarks, is_drawing):
        h, w, _ = frame.shape

        if self.mode2.state == "PLAYING":
            self.capture.update(landmarks, is_drawing)
            preds = self.ai.predict_top3(
                self.capture.completed_strokes,
                self.capture.current_stroke
            )
            prev_state = self.mode2.state
            new_state = self.mode2.update(preds)

            # Log result once when round finishes (Phase 4)
            if prev_state == "PLAYING" and new_state in ("WON", "LOST"):
                self.ai.log_round_result(
                    self.mode2.secret_word,
                    preds,
                    success=(new_state == "WON")
                )

        self._draw_strokes_on_canvas(frame, w, h)

        # HUD
        rem = self.mode2.get_remaining_time()
        timer_color = (0, 255, 0) if rem > 3.0 else (0, 0, 255)
        cv2.putText(frame, f"MODE 2: BEAT THE TIMER | Score: {self.mode2.score}",
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 0), 2)
        cv2.putText(frame, f"Draw: {self.mode2.secret_word.upper()}",
                    (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)
        cv2.putText(frame, f"Time: {rem:.1f}s",
                    (w - 170, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.85, timer_color, 2)

        # Show Top-3 AI Predictions
        y_pos = 115
        cv2.putText(frame, "AI Top-3 Guesses:", (10, y_pos),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 2)
        for idx, (label, conf) in enumerate(self.ai.latest_predictions, start=1):
            y_pos += 28
            cv2.putText(frame, f"{idx}. {label} ({conf * 100:.1f}%)", (15, y_pos),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        # Round End Banner
        if self.mode2.state == "WON":
            cv2.putText(frame, f"AI GUESSED IT! +{self.mode2.last_round_points} pts",
                        (40, h // 2), cv2.FONT_HERSHEY_SIMPLEX, 0.95, (0, 255, 0), 3)
            cv2.putText(frame, "Press [N] for Next Round | [M] Menu",
                        (40, h // 2 + 40), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
        elif self.mode2.state == "LOST":
            cv2.putText(frame, f"TIME'S UP! Word was: {self.mode2.secret_word}",
                        (40, h // 2), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 3)
            cv2.putText(frame, "Press [N] for Next Round | [M] Menu",
                        (40, h // 2 + 40), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)

        return frame

    def _render_mode3(self, frame, landmarks, is_drawing):
        h, w, _ = frame.shape
        self.mode3.update_timer()

        if self.mode3.state == "REVEAL":
            # Black out camera so Player 2 can't get hints early; show word to Player 1
            screen = np.zeros_like(frame)
            cv2.putText(screen, "MODE 3: DRAW & GUESS (Player 2 Look Away!)",
                        (30, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            cv2.putText(screen, f"Player 1 Secret Word: {self.mode3.secret_word.upper()}",
                        (30, 140), cv2.FONT_HERSHEY_SIMPLEX, 0.95, (0, 255, 0), 2)
            cv2.putText(screen, "Press [SPACE] when Player 1 is ready to draw",
                        (30, 210), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
            return screen

        elif self.mode3.state == "DRAWING":
            # Capture drawing; DO NOT run or display AI predictions (Phase 3.7)
            self.capture.update(landmarks, is_drawing)
            self._draw_strokes_on_canvas(frame, w, h)

            rem = self.mode3.get_draw_remaining_time()
            cv2.putText(frame, f"PLAYER 1 DRAWING | Time: {rem:.1f}s",
                        (10, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 255), 2)
            cv2.putText(frame, "Press [ENTER] if finished early | [C] Clear",
                        (10, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            return frame

        elif self.mode3.state == "GUESSING":
            # Clean canvas showing ONLY Player 1's drawing (No AI predictions!)
            board = np.zeros_like(frame)
            self._draw_strokes_on_canvas(board, w, h, color=(255, 255, 255), thickness=5)

            cv2.putText(board, "PLAYER 2: TYPE YOUR GUESS & PRESS [ENTER]",
                        (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            cv2.putText(board, f"Your Guess: {self.mode3.player2_guess}_",
                        (20, h - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 255, 0), 2)
            return board

        elif self.mode3.state == "RESULT":
            board = np.zeros_like(frame)
            self._draw_strokes_on_canvas(board, w, h, color=(150, 150, 150), thickness=3)

            msg = "CORRECT! +100 pts each" if self.mode3.is_correct else "WRONG GUESS!"
            color = (0, 255, 0) if self.mode3.is_correct else (0, 0, 255)

            cv2.putText(board, msg, (30, 70), cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 3)
            cv2.putText(board, f"Secret Word: {self.mode3.secret_word} | Guess: {self.mode3.player2_guess}",
                        (30, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(board, f"Scores -> P1: {self.mode3.p1_score} | P2: {self.mode3.p2_score}",
                        (30, 165), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 255), 2)
            cv2.putText(board, "Press [N] Next Round | [M] Menu",
                        (30, h - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (200, 200, 200), 2)
            return board

    def run(self):
        try:
            while self.camera.isOpened():
                ret, frame = self.camera.read()
                if not ret:
                    break

                frame = cv2.flip(frame, 1)

                # Hand tracking & pinch detection from Member 1's modules
                if self.active_mode in ("MODE2", "MODE3"):
                    frame, landmarks = self.tracker.process_frame(frame)
                    is_drawing, _ = self.detector.detect(landmarks)
                else:
                    landmarks, is_drawing = None, False

                # Render active screen
                if self.active_mode == "MENU":
                    display_frame = self._render_menu(frame)
                elif self.active_mode == "MODE2":
                    display_frame = self._render_mode2(frame, landmarks, is_drawing)
                elif self.active_mode == "MODE3":
                    display_frame = self._render_mode3(frame, landmarks, is_drawing)

                cv2.imshow("AI Drawing Battle", display_frame)

                key = cv2.waitKey(1) & 0xFF

                # Handle typing first if Player 2 is guessing in Mode 3
                if self.active_mode == "MODE3" and self.mode3.state == "GUESSING":
                    if key != 255:
                        self.mode3.handle_typing(key)
                    continue

                # Global & mode controls
                if key == ord("q"):
                    break
                elif key == ord("m"):
                    self.active_mode = "MENU"
                elif key == ord("2"):
                    self._switch_to_mode2()
                elif key == ord("3"):
                    self._switch_to_mode3()
                elif key == ord("c"):
                    self._reset_canvas()
                elif key == ord("n"):
                    if self.active_mode == "MODE2":
                        self._switch_to_mode2()
                    elif self.active_mode == "MODE3":
                        self._switch_to_mode3()
                elif key == ord(" ") and self.active_mode == "MODE3":
                    self.mode3.begin_drawing()
                elif key in (13, 10) and self.active_mode == "MODE3":
                    self.mode3.finish_drawing()

        finally:
            self.camera.release()
            self.tracker.close()
            cv2.destroyAllWindows()
            print("\n=== Phase 4: System Performance & Error Report ===")
            print(self.ai.get_performance_report())


if __name__ == "__main__":
    game = AIDrawingBattleGame()
    game.run()
